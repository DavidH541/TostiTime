﻿namespace TostiTime.Core.Entities;

public class EntityBase
{
    public int Id { get; set; }
}
