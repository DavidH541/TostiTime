export const environment = {
    production: false,
    baseUrl: "https://tostitimeapi.azurewebsites.net/api",
    firstName: 'tester', 
    defaultOffice: "Rotterdam",    
};
