﻿namespace TostiTime.Core.Entities;

public class User
{
    //authorization and authentication stuff, managed identity?
}