export interface Reservation {
    personId: number;
    occupiedSince: Date;
    occupiedUntil: Date;
}