export interface Person{
    id: number;
    firstName: string;
    officeId: number;
}