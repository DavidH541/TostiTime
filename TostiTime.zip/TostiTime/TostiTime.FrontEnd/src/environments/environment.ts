export const environment = {
    production: true,
    baseUrl: "https://tostitimeapi.azurewebsites.net/api",
    defaultOffice: "Rotterdam",    
};
